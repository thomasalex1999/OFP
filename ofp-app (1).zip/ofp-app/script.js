
document.getElementById('fileInput').addEventListener('change', function(event) {
    const reader = new FileReader();
    reader.onload = function(e) {
        document.getElementById('ofpOutput').textContent = e.target.result;
    };
    reader.readAsText(event.target.files[0]);
});
