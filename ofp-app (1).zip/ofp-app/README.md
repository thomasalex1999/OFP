
# OFP App

This is a simple Operational Flight Plan (OFP) viewer built using HTML, CSS, and JavaScript.  
It allows pilots or dispatchers to upload and view the contents of an OFP text file in the browser.

## Features

- Upload OFP text files and display their contents.
- Clean, responsive interface for quick viewing.
- Easy to modify and expand for custom airline workflows.

## How to Use

1. Open `index.html` in your browser.
2. Click the file input to upload your OFP `.txt` file.
3. View the contents instantly on screen.

## Folder Structure

```
ofp-app/
├── index.html       # Main UI
├── style.css        # Basic styling
├── script.js        # JavaScript to handle file input
└── README.md        # This file
```

## License

This project is open source and free to use.
